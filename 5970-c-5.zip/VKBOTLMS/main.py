from flask import Flask

app = Flask(__name__)


@app.route('/')
@app.route('/index')
def index():
    return "И на Марсе будут яблони цвести!"


@app.route('/promotion')
def promotion():
    phrases = ["Человечество вырастает из детства.", "Человечеству мала одна планета.",
               "Мы сделаем обитаемыми безжизненные пока планеты.", "И начнем с Марса!", "Присоединяйся!"]
    return "<br>".join(phrases)


@app.route('/image_mars')
def image_mars():
    return '''<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous">
    <title>Привет, Марс!</title>
  </head>
  <body>
    <div class="container">
      <h1 class="title">Привет, Марс!</h1>
      <img width=200 height=200 src="static/img/mars.png" alt="здесь должна была быть картинка, но не нашлась">
    </div>
  </body>
</html>'''


@app.route('/promotion_image')
def promotion_image():
    return '''<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous">
                    <link rel="stylesheet" href="static/css/style.css">
    <title>Привет, Марс!</title>
  </head>
  <body>
    <div class="container">
      <h1 class="title">Привет, Марс!</h1>
      <img width=200 height=200 src="static/img/mars.png" alt="здесь должна была быть картинка, но не нашлась">
      <div class="titles">
        <p class="titles__item titles__item__1">1</p>
        <p class="titles__item titles__item__2">2</p>
        <p class="titles__item titles__item__3">3</p>
        <p class="titles__item titles__item__4">4</p>
      </div>
    </div>
  </body>
</html>'''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
